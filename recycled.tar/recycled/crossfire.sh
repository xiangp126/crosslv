#!/bin/bash
# Start ss local service
sslocal -c /etc/shadowsocks.json
